def pascal(rows):
    row = [1]
    for _ in range(rows):
        new_row = [1]
        for i in range(len(row) - 1):
            new_row.append(row[i] + row[i + 1])
        new_row.append(1)
        row = new_row
    return row
    

n = int(input())

for j in range(n):
	print(*pascal(j), sep=" ")