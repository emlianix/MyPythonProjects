n = int(input())
cnt = 0

for _ in range(n):
	s = input()
	if s.count("11") >= 3:
		cnt += 1
		
print(cnt)