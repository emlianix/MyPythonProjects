def get_factors(num):
	divisors = []
	for i in range(1, num +1):
		if num % i == 0:
			divisors.append(i)
	return divisors
	
n = int(input())
print(get_factors(n))